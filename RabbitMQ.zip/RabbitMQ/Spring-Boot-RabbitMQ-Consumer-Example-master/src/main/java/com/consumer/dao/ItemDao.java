package com.consumer.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.consumer.model.Item;

@Repository
public class ItemDao {

	@Autowired
    JdbcTemplate jdbcTemplate;
	
	  public int insert(Item item) {
	        return jdbcTemplate.update("insert into items (item_name, category, description) " + "values(?, ?, ?)",
	            new Object[] {
	            		item.getItemName(), item.getCategory(), item.getDescription()
	            });
	    }
}
