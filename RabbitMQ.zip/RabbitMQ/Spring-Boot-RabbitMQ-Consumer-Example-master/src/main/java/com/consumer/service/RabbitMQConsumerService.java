package com.consumer.service;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.consumer.dao.ItemDao;
import com.consumer.model.Item;

@Service
public class RabbitMQConsumerService {
	
	@Autowired
	ItemDao dao;
   // private static final String QUEUE="items-queue";
	 private static final String QUEUE="producer.queue";
    @RabbitListener(queues = QUEUE)
    public void receiveMessage(Item item) {
    	dao.insert(item);
        System.out.println("Received Message from Items Queue >>"+item);
    }
}
