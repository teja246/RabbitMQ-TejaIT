package com.producer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.producer.model.Item;
import com.producer.service.RabbitMQSender;

@RestController
@RequestMapping(value = "/producer-rabbitmq/")
public class RabbitMQWebController {

	@Autowired
	RabbitMQSender rabbitMQSender;

	@GetMapping(value = "/producer")
	public String producer() {
	//@RequestParam("itemName") String itemName,@RequestParam("category") String category,@RequestParam("description") String description
	Item item=new Item();
	item.setItemName("iPhone 13 pro");
	item.setCategory("Mobiles");
	item.setDescription("Apple iPhone 13 Pro 128 GB, Pacific Blue");
		rabbitMQSender.send(item);
		return "Message sent to the RabbitMQ JavaInUse Successfully";
	}

}

