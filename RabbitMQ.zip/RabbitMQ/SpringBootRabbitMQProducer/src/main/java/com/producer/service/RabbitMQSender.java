package com.producer.service;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.producer.model.Item;

@Service
public class RabbitMQSender {
	
	@Autowired
	private AmqpTemplate amqpTemplate;
	
	@Value("${producer.rabbitmq.exchange}")
	private String exchange;
	
	@Value("${producer.rabbitmq.routingkey}")
	private String routingkey;	
	//String kafkaTopic = "producer_rabbit_mq_topic";
	
	public void send(Item item) {
		amqpTemplate.convertAndSend(exchange, routingkey, item);
		System.out.println("Send msg = " + item);
	    
	}
}